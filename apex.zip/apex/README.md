# APEX Trading Bot

这是一个针对 APEX 平台的自动化交易脚本，仿照 `main.go` 的策略逻辑实现。

## 功能特性

- ✅ 周期性市价开仓 + 限价平仓策略
- ✅ 价格区间过滤
- ✅ 精度控制（数量和价格）
- ✅ 定期维护机制（取消挂单 + 平仓）
- ✅ 支持测试网和主网
- ✅ 调试模式
- ✅ 优雅退出

## 安装依赖

```bash
pip install -r requirements.txt
```

或直接安装 APEX SDK：

```bash
pip install apexpro
```

## APEX 认证说明

APEX 使用 zkLink 签名机制，需要以下认证信息：

1. **API 凭证** (用于账户查询和订单管理):
   - `API_KEY` - API密钥
   - `API_SECRET` - API密钥secret
   - `API_PASSPHRASE` - API密钥口令

2. **ZK 签名密钥** (用于订单签名):
   - `ZK_SEEDS` - ZK seeds (十六进制格式，不带 0x 前缀)
   - `ZK_L2_KEY` - ZK L2 公钥

### 如何获取认证信息

参考 APEX 官方文档：
- [APEX API 文档](https://api-docs.pro.apex.exchange/#introduction)
- [注册流程](https://api-docs.pro.apex.exchange/practice/index.html#registration)
- [Python SDK 示例](https://github.com/ApeX-Protocol/apexpro-openapi)

## 使用方法

### 基本用法

```bash
python apex_trading.py \
  -symbol BTC-USDT \
  -side BUY \
  -size 10.0 \
  -step 0.002 \
  -seconds 60 \
  -price_min 20000 \
  -price_max 50000 \
  -precision_base 3 \
  -precision_quote 1 \
  -api_key "your_api_key" \
  -api_secret "your_api_secret" \
  -api_passphrase "your_passphrase" \
  -zk_seeds "your_zk_seeds" \
  -zk_l2_key "your_l2_key"
```

### 使用环境变量（推荐）

为了避免命令行历史记录泄露密钥，推荐使用环境变量：

```bash
# 设置环境变量
export API_KEY="your_api_key"
export API_SECRET="your_api_secret"
export API_PASSPHRASE="your_passphrase"
export ZK_SEEDS="your_zk_seeds"
export ZK_L2_KEY="your_l2_key"

# 运行脚本
python apex_trading.py \
  -symbol BTC-USDT \
  -side BUY \
  -size 10.0 \
  -step 0.002 \
  -seconds 60 \
  -price_min 20000 \
  -price_max 50000 \
  -precision_base 3 \
  -precision_quote 1
```

### 测试网模式

```bash
python apex_trading.py \
  -symbol BTC-USDT \
  -side BUY \
  -size 10.0 \
  -step 0.002 \
  -seconds 60 \
  -price_min 20000 \
  -price_max 50000 \
  -precision_base 3 \
  -precision_quote 1 \
  -testnet
```

## 参数说明

### 必需参数

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `-symbol` | string | 交易对（APEX格式：BTC-USDT） | `BTC-USDT` |
| `-side` | string | 首次市价单方向：BUY 或 SELL | `BUY` |
| `-size` | float | 每次市价单的金额（计价资产） | `10.0` |
| `-step` | float | 限价单的价格偏移比例 | `0.002` (0.2%) |
| `-seconds` | int | 每次循环间隔秒数（最小5秒） | `60` |
| `-price_min` | float | 开仓价格下限 | `20000.0` |
| `-price_max` | float | 开仓价格上限 | `50000.0` |
| `-precision_base` | int | 数量精度（小数位数） | `3` |
| `-precision_quote` | int | 价格精度（小数位数） | `1` |

### API 认证参数

| 参数 | 环境变量 | 说明 |
|------|----------|------|
| `-api_key` | `API_KEY` | APEX API 密钥 |
| `-api_secret` | `API_SECRET` | APEX API secret |
| `-api_passphrase` | `API_PASSPHRASE` | APEX API 口令 |
| `-zk_seeds` | `ZK_SEEDS` | ZK seeds (hex) |
| `-zk_l2_key` | `ZK_L2_KEY` | ZK L2 公钥 |

### 可选参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `-quiet` | false | 静默模式（减少日志输出） |
| `-debug` | false | 调试模式（详细日志） |
| `-reset` | 10 | 维护周期：每N次成功交易后取消挂单并平仓（0=禁用） |
| `-testnet` | false | 使用测试网 |

## 策略逻辑

脚本实现的策略流程：

1. **获取当前价格** - 从 APEX 获取指定交易对的当前价格
2. **价格范围检查** - 确保价格在 `price_min` 和 `price_max` 之间
3. **下市价单** - 按照 `side` 方向下市价单，数量 = `size / 当前价格`
4. **下限价单** - 市价单成交后，反向挂限价单：
   - 如果先 BUY，则挂 SELL 限价单，价格 = `成交均价 × (1 + step)`
   - 如果先 SELL，则挂 BUY 限价单，价格 = `成交均价 × (1 - step)`
5. **维护循环** - 每完成 `reset` 次成功交易后：
   - 取消所有挂单
   - 平掉所有持仓
   - 重置计数器

## 与 main.go 的差异

由于 APEX 平台的特性，有以下差异：

1. **交易对格式**: APEX 使用 `BTC-USDT`，而不是 `BTCUSDT`
2. **认证机制**: APEX 需要 zkLink 签名，需要额外的 `zk_seeds` 和 `zk_l2_key`
3. **API 结构**: APEX 使用不同的 API 端点和响应格式
4. **订单类型**: APEX 的订单参数和字段名称略有不同

## 调试

启用调试模式查看详细的 API 请求和响应：

```bash
python apex_trading.py -debug [其他参数...]
```

## 安全建议

1. ✅ 使用环境变量存储敏感信息，避免命令行泄露
2. ✅ 首次使用建议在测试网运行（添加 `-testnet` 参数）
3. ✅ 设置合理的价格区间（`price_min` 和 `price_max`）
4. ✅ 从小资金开始测试（调整 `size` 参数）
5. ✅ 监控日志输出，确保策略按预期运行

## 故障排查

### 导入错误

```
Error: apexomni package not installed
```

**解决方案**: 安装 APEX SDK:
```bash
pip install apexpro
```

### 认证失败

```
Failed to initialize client: ...
```

**解决方案**: 
1. 检查 API 凭证是否正确
2. 确认 `zk_seeds` 和 `zk_l2_key` 格式正确（十六进制，小写，无 0x 前缀）
3. 确认使用的是正确的网络（主网/测试网）

### 订单失败

```
Market order failed: ...
```

**解决方案**:
1. 检查账户余额是否充足
2. 确认交易对符号格式正确（如 `BTC-USDT`）
3. 检查精度设置是否符合交易所要求
4. 启用 `-debug` 模式查看详细错误信息

## 参考资料

- [APEX 官方 API 文档](https://api-docs.pro.apex.exchange/#introduction)
- [APEX Python SDK](https://github.com/ApeX-Protocol/apexpro-openapi)
- [APEX API 最佳实践](https://api-docs.pro.apex.exchange/practice/index.html#best-practice)
- [APEX FAQ](https://api-docs.pro.apex.exchange/faq/index.html#frequently-asked-questions)
- [APEX API Demo](https://github.com/ApeX-Protocol/apex-api-demo)

## 许可证

本脚本参考 main.go 实现，仅供学习和参考使用。使用时请遵守 APEX 平台的服务条款。


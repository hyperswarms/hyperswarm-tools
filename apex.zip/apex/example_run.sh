#!/bin/bash
# Example script to run APEX trading bot
# 
# Before running, make sure to:
# 1. Install dependencies: pip install -r requirements.txt
# 2. Set environment variables with your APEX credentials
#
# Usage: ./example_run.sh

# Load environment variables from .env file if it exists
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# Check if required environment variables are set
if [ -z "$API_KEY" ] || [ -z "$API_SECRET" ] || [ -z "$API_PASSPHRASE" ] || [ -z "$ZK_SEEDS" ] || [ -z "$ZK_L2_KEY" ]; then
    echo "Error: Missing required environment variables"
    echo "Please set: API_KEY, API_SECRET, API_PASSPHRASE, ZK_SEEDS, ZK_L2_KEY"
    echo "You can create a .env file based on .env.example"
    exit 1
fi

# Example configuration for BTC-USDT trading
SYMBOL="BTC-USDT"
SIDE="BUY"          # First order direction: BUY or SELL
SIZE="10.0"         # Order size in USDT
STEP="0.002"        # 0.2% profit target for limit orders
SECONDS="60"        # Wait 60 seconds between iterations
PRICE_MIN="20000"   # Only trade when BTC price >= 20000
PRICE_MAX="50000"   # Only trade when BTC price <= 50000
PRECISION_BASE="3"  # BTC quantity precision (e.g., 0.001)
PRECISION_QUOTE="1" # Price precision (e.g., 20000.0)
RESET="10"          # Cancel orders and close positions every 10 successful trades

# Run in testnet mode (remove -testnet for mainnet)
python apex_trading.py \
  -symbol "$SYMBOL" \
  -side "$SIDE" \
  -size "$SIZE" \
  -step "$STEP" \
  -seconds "$SECONDS" \
  -price_min "$PRICE_MIN" \
  -price_max "$PRICE_MAX" \
  -precision_base "$PRECISION_BASE" \
  -precision_quote "$PRECISION_QUOTE" \
  -reset "$RESET" \
  -testnet \
  -debug

# For production (mainnet), remove -testnet and -debug:
# python apex_trading.py \
#   -symbol "$SYMBOL" \
#   -side "$SIDE" \
#   -size "$SIZE" \
#   -step "$STEP" \
#   -seconds "$SECONDS" \
#   -price_min "$PRICE_MIN" \
#   -price_max "$PRICE_MAX" \
#   -precision_base "$PRECISION_BASE" \
#   -precision_quote "$PRECISION_QUOTE" \
#   -reset "$RESET"


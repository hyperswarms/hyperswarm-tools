#!/usr/bin/env python3
"""
APEX Trading Bot - Random Trading Strategy
Mirrors the logic from main.go but adapted for APEX platform
"""

import argparse
import time
import sys
import signal
import os
import decimal
from decimal import Decimal
from typing import Optional, Dict, Any

try:
    from apexomni.http_private_sign import HttpPrivateSign
    from apexomni.constants import NETWORKID_MAIN, NETWORKID_TEST, APEX_OMNI_HTTP_MAIN, APEX_OMNI_HTTP_TEST
except ImportError:
    print("Error: apexomni package not installed. Install with: pip install apexpro")
    print("See: https://github.com/ApeX-Protocol/apexpro-openapi")
    sys.exit(1)


class Config:
    """Configuration for the trading bot"""
    def __init__(self):
        self.symbol: str = ""
        self.side: str = ""
        self.size: float = 0.0
        self.step: float = 0.0
        self.seconds: int = 0
        self.price_min: float = 0.0
        self.price_max: float = 0.0
        self.precision_base: int = 0
        self.precision_quote: int = 0
        self.api_key: str = ""
        self.api_secret: str = ""
        self.api_passphrase: str = ""
        self.zk_seeds: str = ""
        self.zk_l2_key: str = ""
        self.quiet: bool = False
        self.debug: bool = False
        self.reset: int = 10
        self.testnet: bool = False


class TradingBot:
    """APEX Trading Bot"""
    
    def __init__(self, config: Config):
        self.config = config
        self.client: Optional[HttpPrivateSign] = None
        self.running = True
        self.t_count = 0
        self.account_data = None
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        print("\nReceived signal, exiting...")
        self.running = False
        
    def _log(self, message: str, force: bool = False):
        """Log message if not in quiet mode"""
        if force or self.config.debug or not self.config.quiet:
            print(message)
            
    def _debug(self, message: str):
        """Log debug message"""
        if self.config.debug:
            print(f"[DEBUG] {message}")
            
    def initialize(self):
        """Initialize the APEX client"""
        try:
            # Determine network
            if self.config.testnet:
                endpoint = APEX_OMNI_HTTP_TEST
                network_id = NETWORKID_TEST
                env_name = "TESTNET"
            else:
                endpoint = APEX_OMNI_HTTP_MAIN
                network_id = NETWORKID_MAIN
                env_name = "MAINNET"
                
            self._log(f"Initializing APEX client on {env_name}...")
            
            # Create client with authentication
            api_credentials = {
                'key': self.config.api_key,
                'secret': self.config.api_secret,
                'passphrase': self.config.api_passphrase
            }
            
            self.client = HttpPrivateSign(
                endpoint,
                network_id=network_id,
                zk_seeds=self.config.zk_seeds,
                zk_l2Key=self.config.zk_l2_key,
                api_key_credentials=api_credentials
            )
            
            # Fetch account and config data
            self._debug("Fetching account configuration...")
            configs = self.client.configs_v3()
            self.account_data = self.client.get_account_v3()
            
            self._log(f"Client initialized successfully for account: {self.account_data.get('account', {}).get('positionId', 'N/A')}")
            return True
            
        except Exception as e:
            print(f"Failed to initialize client: {e}")
            return False
            
    def get_current_price(self) -> Optional[float]:
        """Get current ticker price for symbol"""
        try:
            # APEX uses different symbol format: BTC-USDT instead of BTCUSDT
            result = self.client.get_ticker_v3(symbol=self.config.symbol)
            
            if result and 'data' in result:
                ticker = result['data']
                price_str = ticker.get('oraclePrice') or ticker.get('indexPrice') or ticker.get('close')
                if price_str:
                    price = float(price_str)
                    self._debug(f"Current price for {self.config.symbol}: {price}")
                    return price
                    
            self._log(f"Failed to parse price from ticker response: {result}")
            return None
            
        except Exception as e:
            self._log(f"Error fetching current price: {e}")
            return None
            
    def floor_to_decimals(self, value: float, decimals: int) -> float:
        """Floor value to specified decimal places"""
        if decimals < 0:
            return value
        multiplier = Decimal(10 ** decimals)
        return float(Decimal(str(value)) * multiplier // 1 / multiplier)
        
    def round_to_decimals(self, value: float, decimals: int) -> float:
        """Round value to specified decimal places"""
        if decimals < 0:
            return value
        return round(value, decimals)
        
    def format_quantity(self, quantity: float) -> str:
        """Format quantity for API request"""
        return f"{quantity:.{self.config.precision_base}f}".rstrip('0').rstrip('.')
        
    def format_price(self, price: float) -> str:
        """Format price for API request"""
        return f"{price:.{self.config.precision_quote}f}".rstrip('0').rstrip('.')
        
    def place_market_order(self, side: str, quantity: float) -> Optional[Dict[str, Any]]:
        """Place a market order"""
        try:
            current_time = time.time()
            qty_str = self.format_quantity(quantity)
            
            self._debug(f"Placing MARKET {side} order: qty={qty_str}")
            
            result = self.client.create_order_v3(
                symbol=self.config.symbol,
                side=side.upper(),
                type="MARKET",
                size=qty_str,
                timestampSeconds=current_time
            )
            
            if result and 'data' in result:
                order_data = result['data']
                self._debug(f"Market order result: {order_data}")
                return order_data
            else:
                self._log(f"Market order failed: {result}")
                return None
                
        except Exception as e:
            self._log(f"Market order error: {e}")
            return None
            
    def place_limit_order(self, side: str, quantity: float, price: float) -> Optional[str]:
        """Place a limit order"""
        try:
            current_time = time.time()
            qty_str = self.format_quantity(quantity)
            price_str = self.format_price(price)
            
            self._debug(f"Placing LIMIT {side} order: qty={qty_str} price={price_str}")
            
            result = self.client.create_order_v3(
                symbol=self.config.symbol,
                side=side.upper(),
                type="LIMIT",
                size=qty_str,
                price=price_str,
                timestampSeconds=current_time
            )
            
            if result and 'data' in result:
                order_data = result['data']
                order_id = order_data.get('id', 'unknown')
                self._debug(f"Limit order placed: id={order_id}")
                return order_id
            else:
                self._log(f"Limit order failed: {result}")
                return None
                
        except Exception as e:
            self._log(f"Limit order error: {e}")
            return None
            
    def cancel_all_open_orders(self) -> bool:
        """Cancel all open orders for the symbol"""
        try:
            self._debug(f"Cancelling all open orders for {self.config.symbol}...")
            
            # Get all open orders
            orders_result = self.client.open_orders_v3(symbol=self.config.symbol)
            
            if orders_result and 'data' in orders_result:
                orders = orders_result['data'].get('orders', [])
                
                for order in orders:
                    order_id = order.get('id')
                    if order_id:
                        try:
                            self.client.delete_order_v3(id=order_id)
                            self._debug(f"Cancelled order: {order_id}")
                        except Exception as e:
                            self._log(f"Failed to cancel order {order_id}: {e}")
                            
                self._log(f"Cancelled {len(orders)} open orders")
                return True
            else:
                self._debug("No open orders to cancel")
                return True
                
        except Exception as e:
            self._log(f"Error cancelling orders: {e}")
            return False
            
    def close_all_positions(self) -> bool:
        """Close all positions for the symbol using reduce-only market orders"""
        try:
            self._debug(f"Closing all positions for {self.config.symbol}...")
            
            # Get current positions
            account_result = self.client.get_account_v3()
            
            if not account_result or 'data' not in account_result:
                self._log("Failed to fetch account data for closing positions")
                return False
                
            positions = account_result['data'].get('openPositions', {})
            
            # Find position for our symbol
            position = positions.get(self.config.symbol)
            
            if not position:
                self._debug(f"No position found for {self.config.symbol}")
                return True
                
            size_str = position.get('size', '0')
            size = float(size_str) if size_str else 0.0
            
            if abs(size) < 0.0001:  # Essentially zero
                self._debug(f"Position size is negligible: {size}")
                return True
                
            # Determine closing side
            if size > 0:
                close_side = "SELL"
                close_qty = abs(size)
            else:
                close_side = "BUY"
                close_qty = abs(size)
                
            close_qty = self.floor_to_decimals(close_qty, self.config.precision_base)
            
            if close_qty <= 0:
                self._debug("Calculated close quantity is zero after precision")
                return True
                
            self._log(f"Closing position: {self.config.symbol} side={close_side} qty={close_qty}")
            
            # Place reduce-only market order
            current_time = time.time()
            qty_str = self.format_quantity(close_qty)
            
            result = self.client.create_order_v3(
                symbol=self.config.symbol,
                side=close_side,
                type="MARKET",
                size=qty_str,
                reduceOnly=True,
                timestampSeconds=current_time
            )
            
            if result and 'data' in result:
                self._log(f"Position closed successfully: {result['data'].get('id')}")
                return True
            else:
                self._log(f"Failed to close position: {result}")
                return False
                
        except Exception as e:
            self._log(f"Error closing positions: {e}")
            return False
            
    def opposite_side(self, side: str) -> str:
        """Get opposite trading side"""
        return "SELL" if side.upper() == "BUY" else "BUY"
        
    def run_iteration(self) -> bool:
        """Run one iteration of the trading loop. Returns True if cycle completed successfully."""
        iteration_start = time.time()
        
        # Check if we need to do maintenance (reset)
        if self.config.reset > 0 and self.t_count == self.config.reset:
            self._log(f"Reset threshold reached (tCount={self.t_count}). Cancelling orders and closing positions...")
            
            if not self.cancel_all_open_orders():
                self._log("Warning: Failed to cancel all orders")
                
            if not self.close_all_positions():
                self._log("Warning: Failed to close all positions")
                
            self.t_count = 0
            return False  # Don't count as successful trade
            
        # Get current price
        price = self.get_current_price()
        if price is None:
            self._log("Failed to fetch price, skipping iteration")
            return False
            
        # Check price range
        if price < self.config.price_min or price > self.config.price_max:
            self._log(f"Price {price:.8f} out of range [{self.config.price_min:.8f}, {self.config.price_max:.8f}], skip")
            return False
            
        # Calculate quantity
        quantity_raw = self.config.size / price
        quantity = self.floor_to_decimals(quantity_raw, self.config.precision_base)
        
        if quantity <= 0:
            self._log("Computed quantity <= 0 after precision control, skip")
            return False
            
        # Place market order
        market_result = self.place_market_order(self.config.side, quantity)
        if market_result is None:
            self._log("MARKET order failed")
            return False
            
        # Parse market order result
        executed_qty_str = market_result.get('size', '0')
        avg_price_str = market_result.get('price') or market_result.get('avgPrice', '0')
        
        executed_qty = float(executed_qty_str) if executed_qty_str else 0.0
        avg_price = float(avg_price_str) if avg_price_str else 0.0
        
        if executed_qty <= 0 or avg_price <= 0:
            self._log(f"Market result invalid executedQty={executed_qty_str} avgPrice={avg_price_str}, skip placing limit")
            return False
            
        # Calculate limit order parameters
        limit_side = self.opposite_side(self.config.side)
        
        if self.config.side.upper() == "BUY":
            limit_price = avg_price * (1 + self.config.step)
        else:
            limit_price = avg_price * (1 - self.config.step)
            
        limit_price = self.round_to_decimals(limit_price, self.config.precision_quote)
        executed_qty_prec = self.floor_to_decimals(executed_qty, self.config.precision_base)
        
        if executed_qty_prec <= 0:
            self._log("Executed quantity after precision <= 0, skip limit order")
            return False
            
        # Place limit order
        order_id = self.place_limit_order(limit_side, executed_qty_prec, limit_price)
        if order_id is None:
            self._log("LIMIT order failed")
            return False
            
        self._log(f"Placed LIMIT {limit_side} orderId={order_id} qty={executed_qty_prec:.8f} price={limit_price:.8f} "
                 f"(from MARKET avgPrice={avg_price:.8f} qty={executed_qty:.8f})")
        
        return True
        
    def run(self):
        """Main trading loop"""
        if not self.initialize():
            sys.exit(1)
            
        interval = max(5, self.config.seconds)  # Minimum 5 seconds
        
        self._log(f"Starting APEX random-trading loop: symbol={self.config.symbol} side={self.config.side.upper()} "
                 f"size={self.config.size} step={self.config.step} seconds={interval} "
                 f"price_min={self.config.price_min} price_max={self.config.price_max} "
                 f"base_prec={self.config.precision_base} quote_prec={self.config.precision_quote} "
                 f"reset={self.config.reset}")
        
        while self.running:
            iteration_start = time.time()
            
            try:
                success = self.run_iteration()
                
                # Increment counter only on successful market order
                if success and self.config.reset > 0:
                    self.t_count += 1
                    self._log(f"tCount incremented to {self.t_count} (reset={self.config.reset})")
                    
            except Exception as e:
                self._log(f"Iteration error: {e}", force=True)
                # Wait longer on error
                time.sleep(interval * 10)
                continue
                
            # Wait for next iteration
            elapsed = time.time() - iteration_start
            remaining = interval - elapsed
            
            if remaining > 0 and self.running:
                time.sleep(remaining)
                
        self._log("Trading bot stopped")


def parse_args() -> Config:
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="APEX Trading Bot - Random Trading Strategy",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment Variables:
  API_KEY           APEX API key
  API_SECRET        APEX API secret
  API_PASSPHRASE    APEX API passphrase
  ZK_SEEDS          ZK seeds for signing (hex format, no 0x prefix)
  ZK_L2_KEY         ZK L2 key for signing

Example:
  python apex_trading.py -symbol BTC-USDT -side BUY -size 10.0 -step 0.002 \\
    -seconds 60 -price_min 20000 -price_max 50000 \\
    -precision_base 3 -precision_quote 1 -reset 10

For more information, see:
  https://github.com/ApeX-Protocol/apexpro-openapi
  https://api-docs.pro.apex.exchange/
"""
    )
    
    # Required parameters
    parser.add_argument('-symbol', type=str, required=True,
                       help='Trading symbol, e.g. BTC-USDT')
    parser.add_argument('-side', type=str, required=True, choices=['BUY', 'SELL', 'buy', 'sell'],
                       help='First market side: BUY or SELL')
    parser.add_argument('-size', type=float, required=True,
                       help='Amount in quote asset per market order (e.g. 10.0)')
    parser.add_argument('-step', type=float, required=True,
                       help='Price step ratio for limit order (e.g. 0.002)')
    parser.add_argument('-seconds', type=int, required=True,
                       help='Interval seconds between attempts (min 5)')
    parser.add_argument('-price_min', type=float, required=True,
                       help='Minimum open price')
    parser.add_argument('-price_max', type=float, required=True,
                       help='Maximum open price')
    parser.add_argument('-precision_base', type=int, required=True,
                       help='Asset precision (quantity decimals)')
    parser.add_argument('-precision_quote', type=int, required=True,
                       help='Price precision (price decimals)')
    
    # API credentials (can come from env vars)
    parser.add_argument('-api_key', type=str, default=os.getenv('API_KEY', ''),
                       help='APEX API key (or set env API_KEY)')
    parser.add_argument('-api_secret', type=str, default=os.getenv('API_SECRET', ''),
                       help='APEX API secret (or set env API_SECRET)')
    parser.add_argument('-api_passphrase', type=str, default=os.getenv('API_PASSPHRASE', ''),
                       help='APEX API passphrase (or set env API_PASSPHRASE)')
    parser.add_argument('-zk_seeds', type=str, default=os.getenv('ZK_SEEDS', ''),
                       help='ZK seeds for order signing (or set env ZK_SEEDS)')
    parser.add_argument('-zk_l2_key', type=str, default=os.getenv('ZK_L2_KEY', ''),
                       help='ZK L2 key for signing (or set env ZK_L2_KEY)')
    
    # Optional parameters
    parser.add_argument('-quiet', action='store_true',
                       help='Suppress per-iteration logs')
    parser.add_argument('-debug', action='store_true',
                       help='Enable verbose debug logs (overrides quiet)')
    parser.add_argument('-reset', type=int, default=10,
                       help='Maintenance cycle: every N successful orders cancel all and close positions (0=disabled)')
    parser.add_argument('-testnet', action='store_true',
                       help='Use APEX testnet instead of mainnet')
    
    args = parser.parse_args()
    
    # Build config
    config = Config()
    config.symbol = args.symbol
    config.side = args.side.upper()
    config.size = args.size
    config.step = args.step
    config.seconds = args.seconds
    config.price_min = args.price_min
    config.price_max = args.price_max
    config.precision_base = args.precision_base
    config.precision_quote = args.precision_quote
    config.api_key = args.api_key
    config.api_secret = args.api_secret
    config.api_passphrase = args.api_passphrase
    config.zk_seeds = args.zk_seeds
    config.zk_l2_key = args.zk_l2_key
    config.quiet = args.quiet
    config.debug = args.debug
    config.reset = args.reset
    config.testnet = args.testnet
    
    return config


def validate_config(config: Config) -> Optional[str]:
    """Validate configuration. Returns error message if invalid, None if valid."""
    if not config.symbol:
        return "symbol is required"
    if not config.side or config.side not in ['BUY', 'SELL']:
        return "side must be BUY or SELL"
    if config.size <= 0:
        return "size must be > 0"
    if config.step <= 0:
        return "step must be > 0"
    if config.seconds <= 0:
        return "seconds must be > 0"
    if config.price_min <= 0:
        return "price_min must be > 0"
    if config.price_max <= 0:
        return "price_max must be > 0"
    if config.price_min > config.price_max:
        return "price_min must be <= price_max"
    if config.precision_base < 0:
        return "precision_base must be >= 0"
    if config.precision_quote < 0:
        return "precision_quote must be >= 0"
    if not config.api_key:
        return "api_key is required (use -api_key or env API_KEY)"
    if not config.api_secret:
        return "api_secret is required (use -api_secret or env API_SECRET)"
    if not config.api_passphrase:
        return "api_passphrase is required (use -api_passphrase or env API_PASSPHRASE)"
    if not config.zk_seeds:
        return "zk_seeds is required (use -zk_seeds or env ZK_SEEDS)"
    if not config.zk_l2_key:
        return "zk_l2_key is required (use -zk_l2_key or env ZK_L2_KEY)"
    
    return None


def main():
    """Main entry point"""
    config = parse_args()
    
    # Validate config
    error = validate_config(config)
    if error:
        print(f"Configuration error: {error}")
        sys.exit(1)
        
    # Create and run bot
    bot = TradingBot(config)
    bot.run()


if __name__ == "__main__":
    main()

